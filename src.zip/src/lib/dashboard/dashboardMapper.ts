import type {
  DashboardSourceData,
  LearningPathRow,
  StepProgressRow,
} from "./dashboardService";

import type {
  DashboardTopic,
  MasteryPoint,
} from "./types";

export interface DashboardMappedData {
  studentName: string;
  topics: DashboardTopic[];
  masteryHistory: MasteryPoint[];
  quizAttemptsCount: number;
}

function clampPercentage(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

function getEffectiveProgress(
  step: DashboardSourceData["steps"][number],
  progress: StepProgressRow | undefined,
): number {
  // Status selesai dari tabel tahap menjadi sumber utama.
  if (step.status === "completed") return 100;

  // Gunakan progres tersimpan jika tahap belum selesai.
  if (progress) {
    if (
      progress.status === "completed" ||
      progress.progress_percent >= 100
    ) {
      return 100;
    }

    return clampPercentage(progress.progress_percent);
  }

  if (step.status === "in_progress") return 0;

  return 0;
}

function getEffectiveStatus(
  step: DashboardSourceData["steps"][number],
  progress: StepProgressRow | undefined,
): DashboardTopic["status"] {
  if (
    step.status === "completed" ||
    progress?.status === "completed" ||
    (progress?.progress_percent ?? 0) >= 100
  ) {
    return "completed";
  }

  if (
    step.status === "in_progress" ||
    progress?.status === "in_progress" ||
    (progress?.progress_percent ?? 0) > 0
  ) {
    return "in_progress";
  }

  if (step.status === "locked") return "locked";

  return "not_started";
}

export function mapDashboardData(
  source: DashboardSourceData,
): DashboardMappedData {
  const topicsById = new Map(
    source.topics.map((topic) => [topic.id, topic]),
  );

  // fetchDashboardData mengurutkan learning path terbaru terlebih dahulu.
  const pathByGoal = new Map<string, LearningPathRow>();

  for (const path of source.paths) {
    if (!pathByGoal.has(path.goal_id)) {
      pathByGoal.set(path.goal_id, path);
    }
  }

  // Simpan progres terbaru untuk setiap tahap.
  const progressByStep = new Map<string, StepProgressRow>();

  for (const progress of source.progressRows) {
    const existing = progressByStep.get(progress.step_id);

    if (
      !existing ||
      new Date(progress.updated_at).getTime() >
        new Date(existing.updated_at).getTime()
    ) {
      progressByStep.set(progress.step_id, progress);
    }
  }

  const stepsByPath = new Map<
    string,
    DashboardSourceData["steps"]
  >();

  for (const step of source.steps) {
    const pathSteps = stepsByPath.get(step.learning_path_id) ?? [];
    pathSteps.push(step);
    stepsByPath.set(step.learning_path_id, pathSteps);
  }

  const topics: DashboardTopic[] = source.goals.map((goal) => {
    const topic =
      goal.topic_id !== null
        ? topicsById.get(goal.topic_id)
        : undefined;

    const path = pathByGoal.get(goal.id);

    const pathSteps = path
      ? [...(stepsByPath.get(path.id) ?? [])].sort(
          (a, b) => a.order_sequence - b.order_sequence,
        )
      : [];

    const effectiveProgress = pathSteps.map((step) =>
      getEffectiveProgress(step, progressByStep.get(step.id)),
    );

    const effectiveStatuses = pathSteps.map((step) =>
      getEffectiveStatus(step, progressByStep.get(step.id)),
    );

    const progress =
      pathSteps.length > 0
        ? clampPercentage(
            effectiveProgress.reduce(
              (total, value) => total + value,
              0,
            ) / pathSteps.length,
          )
        : 0;

    const allStepsCompleted =
      pathSteps.length > 0 &&
      effectiveStatuses.every((status) => status === "completed");

    const hasProgress = effectiveStatuses.some(
      (status) =>
        status === "in_progress" || status === "completed",
    );

    const status: DashboardTopic["status"] =
      path?.status === "completed" || allStepsCompleted
        ? "completed"
        : hasProgress
          ? "in_progress"
          : "not_started";

    return {
      id: goal.id,
      title: topic?.name ?? goal.requested_topic,
      description:
        topic?.description ??
        "Lanjutkan perjalanan belajar sesuai tujuan yang kamu pilih.",
      progress: status === "completed" ? 100 : progress,
      status,
      href: path
        ? `/learning-path/${path.id}`
        : "/topicSelect",
    };
  });

  const masteryHistory: MasteryPoint[] = source.masteryRows
    .filter((item) => item.last_assessed_at !== null)
    .map((item) => ({
      label: item.skill_key,
      mastery: clampPercentage(item.p_known * 100),
    }));

  return {
    studentName: source.studentName,
    topics,
    masteryHistory,
    quizAttemptsCount: source.quizAttemptsCount,
    streakDays: source.streakDays,
  };
}
