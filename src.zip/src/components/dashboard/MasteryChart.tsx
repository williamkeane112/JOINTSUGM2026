import { Brain, TrendingUp } from "lucide-react";

interface MasteryPoint {
  label: string;
  mastery: number;
}

interface MasteryChartProps {
  data?: MasteryPoint[];
  currentMastery?: number;
}

/**
 * student_mastery menyimpan snapshot saat ini per skill, bukan histori
 * penguasaan harian. Karena itu visualisasi dibuat sebagai bar per skill,
 * bukan grafik garis yang menyiratkan adanya tren waktu.
 */
export default function MasteryChart({
  data = [],
  currentMastery = 0,
}: MasteryChartProps) {
  const safeMastery = Math.min(100, Math.max(0, Math.round(currentMastery)));

  const points = data
    .filter((item) => Number.isFinite(item.mastery))
    .slice(-7)
    .map((item) => ({
      ...item,
      mastery: Math.min(100, Math.max(0, Math.round(item.mastery))),
    }));

  const hasData = points.length > 0;

  return (
    <section className="rounded-3xl border border-[#EAE2F0] bg-white p-5 shadow-sm sm:p-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#F1EBFF] text-[#7560B5]">
            <Brain size={22} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-[#29243B]">
              Penguasaan Materi
            </h2>
            <p className="mt-1 text-sm text-[#93879F]">
              Tingkat penguasaan saat ini untuk setiap skill yang sudah dinilai.
            </p>
          </div>
        </div>

        <div className="rounded-2xl bg-[#F1EBFF] px-4 py-3">
          <p className="text-xs text-[#81768B]">Rata-rata penguasaan</p>
          <p className="mt-1 flex items-center gap-2 text-2xl font-bold text-[#7560B5]">
            {safeMastery}%
            <TrendingUp size={19} />
          </p>
        </div>
      </div>

      {hasData ? (
        <div className="mt-6 space-y-5">
          {points.map((point) => (
            <div key={point.label} className="min-w-0">
              <div className="mb-2 flex items-center justify-between gap-3">
                <span
                  className="truncate text-sm font-medium text-[#625873]"
                  title={point.label}
                >
                  {point.label.replace(/_/g, " ")}
                </span>
                <span className="shrink-0 text-sm font-bold text-[#7560B5]">
                  {point.mastery}%
                </span>
              </div>
              <div
                className="h-2.5 overflow-hidden rounded-full bg-[#F1EBFF]"
                role="progressbar"
                aria-label={`Penguasaan ${point.label}`}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={point.mastery}
              >
                <div
                  className="h-full rounded-full bg-[#7560B5] transition-all duration-500"
                  style={{ width: `${point.mastery}%` }}
                />
              </div>
            </div>
          ))}
          <p className="border-t border-[#F0E8F2] pt-3 text-xs text-[#93879F]">
            Data ini adalah snapshot penguasaan per skill, bukan riwayat perubahan dari waktu ke waktu.
          </p>
        </div>
      ) : (
        <div className="mt-6 flex min-h-48 flex-col items-center justify-center rounded-2xl border border-dashed border-[#DCD2E8] bg-[#FFFDFC] px-5 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#F1EBFF] text-[#7560B5]">
            <TrendingUp size={23} />
          </div>
          <h3 className="mt-3 font-semibold text-[#29243B]">
            Belum ada data penguasaan
          </h3>
          <p className="mt-1 max-w-sm text-sm leading-6 text-[#93879F]">
            Jawab kuis diagnostik atau latihan untuk mulai membangun data penguasaan skill.
          </p>
        </div>
      )}
    </section>
  );
}
